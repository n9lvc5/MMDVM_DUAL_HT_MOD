The binary bootloader and utilities in this folder are from Roger Clark's STM32duino project. You can get the original files and source code from:

https://github.com/rogerclarkmelbourne/Arduino_STM32
https://github.com/rogerclarkmelbourne/STM32duino-bootloader

