/*
 *   Copyright (C) 2009-2016 by Jonathan Naylor G4KLX
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#if !defined(DMRDEFINES_H)
#define  DMRDEFINES_H

#include <stdint.h>

const unsigned int DMR_FRAME_LENGTH_BYTES   = 33U;
const unsigned int DMR_FRAME_LENGTH_BITS    = DMR_FRAME_LENGTH_BYTES * 8U;
const unsigned int DMR_FRAME_LENGTH_SYMBOLS = DMR_FRAME_LENGTH_BYTES * 4U;

const unsigned int DMR_SYNC_LENGTH_BYTES   = 6U;
const unsigned int DMR_SYNC_LENGTH_BITS    = DMR_SYNC_LENGTH_BYTES * 8U;
const unsigned int DMR_SYNC_LENGTH_SYMBOLS = DMR_SYNC_LENGTH_BYTES * 4U;

const unsigned int DMR_EMB_LENGTH_BITS    = 16U;
const unsigned int DMR_EMB_LENGTH_SYMBOLS = 8U;

const unsigned int DMR_EMBSIG_LENGTH_BITS    = 32U;
const unsigned int DMR_EMBSIG_LENGTH_SYMBOLS = 16U;

const unsigned int DMR_SLOT_TYPE_LENGTH_BITS    = 20U;
const unsigned int DMR_SLOT_TYPE_LENGTH_SYMBOLS = 10U;

const unsigned int DMR_INFO_LENGTH_BITS    = 196U;
const unsigned int DMR_INFO_LENGTH_SYMBOLS = 98U;

const unsigned int DMR_AUDIO_LENGTH_BITS    = 216U;
const unsigned int DMR_AUDIO_LENGTH_SYMBOLS = 108U;

const unsigned int DMR_CACH_LENGTH_BYTES   = 3U;
const unsigned int DMR_CACH_LENGTH_BITS    = DMR_CACH_LENGTH_BYTES * 8U;
const unsigned int DMR_CACH_LENGTH_SYMBOLS = DMR_CACH_LENGTH_BYTES * 4U;

const uint8_t  DMR_SYNC_BYTES_LENGTH     = 7U;
const uint8_t  DMR_MS_DATA_SYNC_BYTES[]  = {0x0DU, 0x5DU, 0x7FU, 0x77U, 0xFDU, 0x75U, 0x70U};
const uint8_t  DMR_MS_VOICE_SYNC_BYTES[] = {0x07U, 0xF7U, 0xD5U, 0xDDU, 0x57U, 0xDFU, 0xD0U};
const uint8_t  DMR_BS_DATA_SYNC_BYTES[]  = {0x0DU, 0xFFU, 0x57U, 0xD7U, 0x5DU, 0xF5U, 0xD0U};
const uint8_t  DMR_BS_VOICE_SYNC_BYTES[] = {0x07U, 0x55U, 0xFDU, 0x7DU, 0xF7U, 0x5FU, 0x70U};
const uint8_t  DMR_S1_DATA_SYNC_BYTES[]  = {0x0FU, 0x7FU, 0xDDU, 0x5DU, 0xDFU, 0xD5U, 0x50U};
const uint8_t  DMR_S1_VOICE_SYNC_BYTES[] = {0x05U, 0xD5U, 0x77U, 0xF7U, 0x75U, 0x7FU, 0xF0U};
const uint8_t  DMR_S2_DATA_SYNC_BYTES[]  = {0x0DU, 0x75U, 0x57U, 0xF5U, 0xFFU, 0x7FU, 0x50U};
const uint8_t  DMR_S2_VOICE_SYNC_BYTES[] = {0x07U, 0xDFU, 0xFDU, 0x5FU, 0x55U, 0xD5U, 0xF0U};
const uint8_t  DMR_SYNC_BYTES_MASK[]     = {0x0FU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xF0U};

const uint64_t DMR_MS_DATA_SYNC_BITS  = 0x0000D5D7F77FD757U;
const uint64_t DMR_MS_VOICE_SYNC_BITS = 0x00007F7D5DD57DFDU;

const uint64_t DMR_BS_DATA_SYNC_BITS  = 0x0000DFF5D5FF757FU;
const uint64_t DMR_BS_VOICE_SYNC_BITS = 0x00007AA02A022A2AU;


//const uint64_t DMR_BS_DATA_SYNC_BITS  = 0x0000DFF5D5FF757FU;
//const uint64_t DMR_BS_VOICE_SYNC_BITS = 0x00007AA02A022A2AU;

const uint64_t DMR_MS_DATA_SYNC_BITS_INV  = 0x00002A28088028A8U;
const uint64_t DMR_MS_VOICE_SYNC_BITS_INV = 0x00008082A22A8202U;
const uint64_t DMR_BS_DATA_SYNC_BITS_INV  = 0x0000200A2A008A80U;
const uint64_t DMR_BS_VOICE_SYNC_BITS_INV = 0x0000855FD5FD55D5U;

const uint64_t DMR_S1_DATA_SYNC_BITS  = 0x0000F7FDD5DDFD55U;
const uint64_t DMR_S1_VOICE_SYNC_BITS = 0x00005D577F7757FFU;
const uint64_t DMR_S2_DATA_SYNC_BITS  = 0x0000D7557F5FF7F5U;
const uint64_t DMR_S2_VOICE_SYNC_BITS = 0x00007DFFD5F55D5FU;
const uint64_t DMR_SYNC_BITS_MASK     = 0x0000FFFFFFFFFFFFU;

const uint32_t DMR_MS_DATA_SYNC_SYMBOLS  = 0x0076286EU;
const uint32_t DMR_MS_VOICE_SYNC_SYMBOLS = 0x0089D791U;
const uint32_t DMR_BS_DATA_SYNC_SYMBOLS  = 0x00439B4DU;
const uint32_t DMR_BS_VOICE_SYNC_SYMBOLS = 0x00BC64B2U;
const uint32_t DMR_S1_DATA_SYNC_SYMBOLS  = 0x0021751FU;
const uint32_t DMR_S1_VOICE_SYNC_SYMBOLS = 0x00DE8AE0U;
const uint32_t DMR_S2_DATA_SYNC_SYMBOLS  = 0x006F8C23U;
const uint32_t DMR_S2_VOICE_SYNC_SYMBOLS = 0x009073DCU;
const uint32_t DMR_SYNC_SYMBOLS_MASK     = 0x00FFFFFFU;

const uint8_t DT_VOICE_PI_HEADER    = 0U;
const uint8_t DT_VOICE_LC_HEADER    = 1U;
const uint8_t DT_TERMINATOR_WITH_LC = 2U;
const uint8_t DT_CSBK               = 3U;
const uint8_t DT_DATA_HEADER        = 6U;
const uint8_t DT_RATE_12_DATA       = 7U;
const uint8_t DT_RATE_34_DATA       = 8U;
const uint8_t DT_IDLE               = 9U;
const uint8_t DT_RATE_1_DATA        = 10U;

#endif

